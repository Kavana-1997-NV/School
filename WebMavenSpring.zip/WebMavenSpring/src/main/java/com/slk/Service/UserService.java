/*package com.slk.Service;

import java.util.List;
import java.util.Map;

import com.slk.Model.User;

public interface UserService {
	public List<Map<String, Object>> findAll();

}
*/