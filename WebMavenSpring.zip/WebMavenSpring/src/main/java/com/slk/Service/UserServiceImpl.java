/*package com.slk.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;


import com.slk.Dao.UserDao;

public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDetailsDao;

	public List<Map<String, Object>> findAll() {
		return userDetailsDao.findAll();
	}
	
//	@Override
//	public int addUserDetails(UserDetails userDetails) {
//		return userDetailsDao.addUserDetails(userDetails);
//	}

}
*/