package com.slk.Model;


public class User {
	private int id;
	private String firstname;
	private String lastname;
	private String email;
	private String password;
	private Long mobile;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", email=" + email
				+ ", password=" + password + ", mobile=" + mobile + "]";
	}
}
//	
//public User() {
//		
//	}
	
	
	/*
	@RequestMapping(value = { "/Login" }, method = RequestMethod.POST)
	public ResponseEntity<Object> checkLogin1(@RequestBody Map<Object, Object> object) throws SQLException {
	logger.info("commando Controller --> login");
		String username = (String) object.get("username");
		String password = (String) object.get("password");
		 System.out.println("--------" + " " + password); 
		JSONObject jsnObj = new JSONObject();
		JSONObject userObj = new JSONObject();
		JSONArray userarray = new JSONArray();
		
		JSONObject jsnbj = new JSONObject();
		JSONArray finJsonArr = new JSONArray();
		JSONObject resultjsnbj = new JSONObject();
		resultjsnbj.put("status","Invalid Credentials");
	
		
		try {
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
             Date date1 = new Date();
			String currentdate = sdf.format(date1);
			date1 = sdf.parse(currentdate);
		   
	    Date date2=sdf.parse("11/04/2020");
	    if(!(date1.compareTo(date2)<0))
	    {
	    	jsnObj.put("status", "service expired");
			return new ResponseEntity<Object>(jsnObj.toString(), HttpStatus.FORBIDDEN);
	    }
	   
			List<Map<String, Object>> loginDetails = commondo.checkLogin(username);
			 System.out.println(loginDetails); 
			//String usertype = loginDetails.get(0).get("usertype").toString();
			if (password.trim() != null || password.trim() != "") {
				if (!(loginDetails.size() > 0)) {
					jsnObj.put("status", "invalid user id");
					return new ResponseEntity<Object>(jsnObj.toString(), HttpStatus.UNAUTHORIZED);
				} else

				{
                         
					if (password.equals(loginDetails.get(0).get("password").toString())) {
						
						logger.info("commando Controller --> login obj-->"+" "+loginDetails);
						JSONObject jsnobj = new JSONObject();
						jsnobj.put("username", loginDetails.get(0).get("username").toString().trim());
						jsnobj.put("usertype", loginDetails.get(0).get("usertype").toString().trim());

						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						String date = dateFormat.format(new Date()).toString();
						 System.out.println("date"+" "+date); 
						jsnobj.put("dateTime",date);
						jsnobj.put("lastlogin", date);
						 System.out.println(jsnobj); 

						String userAuthToken = new HandleAuthToken().generateAuthtoken(jsnobj.toString());
						List<Map<String, Object>> allDogList = commondo.allDogList();
						///////////////////////////////////////////////////////////////
								
						
						String pet_id = "";
						JSONArray jsnDBrdArr = new JSONArray();
						JSONObject trainingObj = new JSONObject();
						int index = -1;
						int progress=0;
						for (int i = 0; i < allDogList.size(); i++) {
                           
							if (pet_id == "" || !pet_id.equalsIgnoreCase(allDogList.get(i).get("pet_id").toString())) {
								// System.out.println("forrrrrrrrrrrrrrrrrrrrrr");
								jsnbj = new JSONObject();
								trainingObj = new JSONObject();
								jsnDBrdArr = new JSONArray();
								pet_id = allDogList.get(i).get("pet_id").toString();
                               // progress=(int) allDogList.get(i).get("progress");
                                progress =Integer.parseInt(allDogList.get(i).get("progress").toString());
							    jsnbj.put("pet_id", allDogList.get(i).get("pet_id").toString());
								jsnbj.put("pet_name", allDogList.get(i).get("pet_name").toString());
								jsnbj.put("progress", progress);
								jsnbj.put("Breed", allDogList.get(i).get("Breed").toString());
								jsnbj.put("trainingCourse", jsnDBrdArr);
								if (!allDogList.get(i).get("trainingCourse").toString().equals("")) {

									trainingObj.put("name", allDogList.get(i).get("trainingCourse"));

									((JSONArray) jsnbj.get("trainingCourse")).put(trainingObj);
								}
								finJsonArr.put(jsnbj);
								index++;
							} else {
								// System.err.println("elxseeeeeeeeeeeeee");
								trainingObj = new JSONObject();
								progress+=Integer.parseInt(allDogList.get(i).get("progress").toString()); 
								 System.err.println("new progress   val"+progress); 
								trainingObj.put("name", allDogList.get(i).get("trainingCourse"));
								((JSONArray) ((JSONObject) finJsonArr.get(index)).get("trainingCourse"))
										.put(trainingObj);
								jsnbj.put("progress", progress);
							}
				
			}
			
						 System.out.println("finJsonArr-------" + " "+finJsonArr); 
			logger.info("commando Controller --> login alldoglist obj"+finJsonArr);
						
						jsnObj.put("AuthToken", userAuthToken);
						jsnObj.put("allDogList",finJsonArr);
						jsnObj.put("Userid", loginDetails.get(0).get("username").toString());
						List<Map<String, Object>> accesslevel = commondo
								.accesslevel(loginDetails.get(0).get("username").toString().trim());
						 System.out.println("after" + " " + accesslevel); 
						 System.out.println("after" + " " + accesslevel.size()); 
						if (accesslevel.size() > 0) {
							userObj = new JSONObject();
							userObj.put("title", "Home");
							userObj.put("url", "/pet-list");
							userObj.put("icon", "home");
							userarray.put(0, userObj);

							if (accesslevel.size() > 1) {
								 System.out.println("both"); 

								if (accesslevel.get(0).get("module").toString().equalsIgnoreCase("Schedule")
										&& accesslevel.get(1).get("module").toString().equalsIgnoreCase("Training")) {
									 System.out.println("both"); 
									
									 * userObj = new JSONObject(); userObj.put("title", "Training");
									 * userObj.put("url", "/pet-list"); userObj.put("icon", "speedometer");
									 * userarray.put(1, userObj);
									 

									userObj = new JSONObject();
									userObj.put("title", "Schedule");
									userObj.put("url", "/schedule");
									userObj.put("icon", "speedometer");
									userarray.put(1, userObj);

									userObj = new JSONObject();
									userObj = new JSONObject();
									userObj.put("title", "Log out");
									userObj.put("url", "/login");
									userObj.put("icon", "log-out");
									userarray.put(2, userObj);

								}
							} else {
								if (accesslevel.get(0).get("module").toString().equalsIgnoreCase("Training")) {
									
									 * userObj = new JSONObject(); userObj.put("title", "Training");
									 * userObj.put("url", "/pet-list"); userObj.put("icon", "speedometer");
									 * userarray.put(1, userObj);
									 
									userObj = new JSONObject();
									userObj.put("title", "Log out");
									userObj.put("url", "/login");
									userObj.put("icon", "log-out");
									userarray.put(1, userObj);
								} else if (accesslevel.get(0).get("module").toString().equalsIgnoreCase("Schedule")) {
									userObj = new JSONObject();
									userObj.put("title", "Schedule");
									userObj.put("url", "/schedule");
									userObj.put("icon", "speedometer");
									userarray.put(1, userObj);
									
									userObj = new JSONObject();
									userObj.put("title", "Log out");
									userObj.put("url", "/login");
									userObj.put("icon", "log-out");
									userarray.put(2, userObj);

								}
								
							}

						}
						
						jsnObj.put("usermenu", userarray);
						return new ResponseEntity<Object>(jsnObj + "", HttpStatus.OK);
					} else {
						 System.out.println("valid"); 
						jsnObj.put("status", "enter valid  password");
						return new ResponseEntity<Object>(jsnObj + "", HttpStatus.UNAUTHORIZED);
					}
				}
			} else {
				 System.out.println("empty"); 
				jsnObj.put("status", "password should not empty");
				return new ResponseEntity<Object>(jsnObj.toString(), HttpStatus.UNAUTHORIZED);
			}

		} catch (Exception e) {
			logger.error("commando controller--> login error: "+e.getMessage());
			e.printStackTrace();
		}
		return new ResponseEntity<Object>(resultjsnbj  + "", HttpStatus.BAD_REQUEST);

	}
	
	*/
	
	
	
	
	
	
	
	
	
	
//	
//	public User(int id,String firstname,String lastname,String email,String password,Long mobile) {
//		this.id=id;
//		this.firstname=firstname;
//		this.lastname=lastname;
//		this.email=email;
//		this.password=password;
//		this.mobile=mobile;
//	}

