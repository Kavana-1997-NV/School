package com.slk.controller;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.slk.Dao.UserDao;
import com.slk.Model.User;

@Controller
@RequestMapping({ "/" })
public class UserController {

	@Autowired
	public UserDao dao;

	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String homePage(ModelMap model) {
		System.err.println("inside controller");
		return "index";
	}

	@RequestMapping("/userform")
	public String logform(Model user) {
		user.addAttribute("command", new User());
		return "userform";
	}
	@RequestMapping("/loginn")
	public String userform(Model user) {
		user.addAttribute("command", new User());
		return "login";
	}

	@RequestMapping(value="/createuser",method=RequestMethod.POST)
	public String createUser(@RequestParam("firstname") String firstname , @RequestParam("lastname") String lastname,@RequestParam("email") String email,@RequestParam("password") String password,@RequestParam("mobile") long mobile){
		User userinfo=new User();
		System.err.println("firstname  "+firstname);
		userinfo.setFirstname(firstname);
		userinfo.setLastname(lastname);
		userinfo.setEmail(email);
		userinfo.setPassword(password);
		userinfo.setMobile(mobile); 
		dao.createUser(userinfo);
		return "login";
	}
	
	
	@RequestMapping(value="/loginform",method=RequestMethod.POST)
	public String getByEmail(@RequestParam String email,@RequestParam String password,Model model){
		JSONObject obj =  new JSONObject();
		System.out.println("email "+email);
		System.out.println("password "+password);
		
		try{
			List<Map<String, Object>> user = dao.getByEmail(email,password);
			System.err.println("user  size  "+user.toString());
		/*	if(user.size()>0){
				model.addAttribute("userdata", user);
				
			}else{
				model.addAttribute("userdata", "Invalid email and password");
			}	
			*/
			
			if(user.size()>0){
				model.addAttribute("userdata", user);
				return "userslist";
					}
		}catch (Exception e) {
		e.printStackTrace();
					}
		return "failed";
	}
	
	@RequestMapping(value="/updateuser/{id}",method=RequestMethod.GET)    
    public String updateusesaveeditbyid(@PathVariable int id, Model model){    
		
		System.err.println(" id  "+id);
		List<Map<String, Object>> user=dao.getUserById(id);    
		System.err.println(user);
        model.addAttribute("editeduserinfo",user);  
        return "edituser";    
    }    
	
	@RequestMapping(value="/updateuser/saveedit",method=RequestMethod.POST)
	public String saveupdate(@RequestParam("id") int id,@RequestParam("firstname") String firstname , @RequestParam("lastname") String lastname,@RequestParam("email") String email,@RequestParam("password") String password,@RequestParam("mobile") long mobile,Model model){	
		try {
			User userinfo=new User();
			System.err.println("firstname  "+firstname);
			userinfo.setFirstname(firstname);
			userinfo.setLastname(lastname);
			userinfo.setEmail(email);
			userinfo.setPassword(password);
			userinfo.setMobile(mobile); 
			userinfo.setId(id);
			User editeduserinfo=new User();
			int vl = dao.saveUpdateById(editeduserinfo);
			if(vl>0){
				return "error";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
			return "edited";
		
	}
	
}
