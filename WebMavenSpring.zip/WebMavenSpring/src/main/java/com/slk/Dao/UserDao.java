package com.slk.Dao;

import java.util.List;
import java.util.Map;

import com.slk.Model.User;

public interface UserDao {
	
	
	List<Map<String, Object>> getByEmail(String email, String password);
	public int createUser(User userinfo);
	List<Map<String, Object>> getUserById(int id);
	int saveUpdateById(User user);
	
}
