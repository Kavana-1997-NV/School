package com.slk.Dao;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.slk.Model.User;
@Repository
public class UserDaoImpl  implements UserDao{

    @Autowired
	private JdbcTemplate jdbcTemplate;

	public void setTemplate(JdbcTemplate jdbcTemplate) {    
	    this.jdbcTemplate = jdbcTemplate;    
	}    
	@Override
	public int createUser(User userinfo){  
		System.err.println(userinfo.toString());
	    String sql="insert into users(firstname,lastname,email,password,mobile) values('"+userinfo.getFirstname()+"','"+userinfo.getLastname()+"','"+userinfo.getEmail()+"','"+userinfo.getPassword()+"','"+userinfo.getMobile()+"')";    
	    System.err.println(jdbcTemplate);
	    return jdbcTemplate.update(sql);    
	}
	@Override
	public List<Map<String, Object>> getByEmail(String email,String password) {
		String sql="select * from users where email=? and password =?";
		return jdbcTemplate.queryForList(sql,email,password);
	}
	
	@Override
	public List<Map<String, Object>> getUserById(int id) {
		String sql = "select * from users where id=?";
		 return jdbcTemplate.queryForList(sql,id);		
	}
	@Override
	public int saveUpdateById(User user) {
		String sql="update users set firstname='"+user.getFirstname()+"', lastname="+user.getLastname()+",email='"+user.getEmail()+"', password="+user.getPassword()+", mobile="+user.getMobile()+" where id="+user.getId()+""; 
		return jdbcTemplate.update(sql);	
	}
	

//	@Override
//	public int saveUpdateById(User user) {
//		String sql="update users set firstname='"+user.getFirstname()+"', lastname="+user.getLastname()+",email='"+user.getEmail()+"', password="+user.getPassword()+", mobile="+user.getMobile()+" where id="+user.getId()+"";    
//		return jdbcTemplate.update(sql); 
//	}
	

		}
	