package OAuth2Security;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;


/**
 * 
 * @author Pavan
 *
 */
public class AESv1 {
	
	
    private static SecretKeySpec secretKey;
    private static byte[] key;
    private static byte[] iv = new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF }; 
    private static IvParameterSpec ivSpec; 

    public static void setKey(String myKey) 
    {
        MessageDigest sha = null;
        try {
            key = myKey.getBytes("UTF-8");
            sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16); 
            secretKey = new SecretKeySpec(key, "AES");
            ivSpec = new IvParameterSpec(iv); 
        } 
        catch (NoSuchAlgorithmException e) {
        } 
        catch (UnsupportedEncodingException e) {
        }
    }
  
    public static String encrypt(String strToEncrypt,int rkey,String key_data)
    {
    	
    	String secret = key_data;
    	if(rkey>0) {
    		secret = key_data+rkey;
    	}
    	
        try
        {
            setKey(secret);
            Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey,ivSpec);
            return (DatatypeConverter.printBase64Binary(cipher.doFinal(strToEncrypt.getBytes("UTF-8")))).toString();
//            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
        } 
        catch (Exception e) 
        {
        	e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String strToDecrypt,int rkey,String key_data){
    	String secret = key_data;
    	if(rkey>0) {
    		secret = key_data+rkey;
    	}
        try{
            setKey(secret);
            Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey,ivSpec);
            byte[] result = DatatypeConverter.parseBase64Binary(strToDecrypt);
            
            return new String(cipher.doFinal(result));
        } catch (Exception e){
        }
        return null;
    }

}
