package OAuth2Security;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.google.gson.Gson;


public class UserAccounts implements RowMapper<UserAccounts> {

     private String username;
     private String usertype;
	 private String authtoken;
     
    public String getUsername() {
		return username;
	}
 
    public void setUsername(String username) {
		this.username = username;
	}


    public String getUsertype() {
		return usertype;
	}
 
    public void setUsertype(String usertype) {
		this.usertype = usertype;
	}  
    
	  public String getAuthtoken() {
		return authtoken;
	}

	public void setAuthtoken(String authtoken) {
		this.authtoken = authtoken;
	}

	@Override public UserAccounts mapRow(ResultSet rs, int rowNum) throws
	  SQLException { UserAccounts userAcc = new UserAccounts();
	  userAcc.setUsername(rs.getString("username").trim());
	  userAcc.setUsertype(rs.getString("usertype").trim());
	  userAcc.setAuthtoken(new HandleAuthToken().generateAuthtoken(new Gson().toJson(userAcc))); return
	  userAcc; }

}
