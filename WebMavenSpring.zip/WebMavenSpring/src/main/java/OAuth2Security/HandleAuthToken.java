package OAuth2Security;

import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.google.gson.Gson;

public class HandleAuthToken {
	final String keyData = "CK2020SLBLR";
	public String generateAuthtoken(String strToEncrypt){
		
		String authToken = "";
		SecureRandom random = new SecureRandom();
		int rKey = random.nextInt(129);
		authToken = AESv1.encrypt(strToEncrypt, rKey, keyData);
		
		return rKey+"-"+authToken;
	}
	
	public String generateDataFromToken(String strToDecrypt){
		
		
		String digits="";
		Matcher m=Pattern.compile("\\d+-").matcher(strToDecrypt);
		if(m.find())digits=m.group();
		
		strToDecrypt = strToDecrypt.replace(digits, "");
		
		digits = digits.replace("-", "");
		
		String decData = AESv1.decrypt(strToDecrypt, Integer.parseInt(digits), keyData);
		
//		System.out.println(strToDecrypt);
		
		return decData;
	}
	
	public UserAccounts validateAuthToken(String authToken){
		UserAccounts userAccount = null;
		try {
			
			String jsonDataString  = generateDataFromToken(authToken);
			System.out.println(jsonDataString);
			if (jsonDataString != null) {
				Gson gson = new Gson();
				userAccount = gson.fromJson(jsonDataString, UserAccounts.class);
			}
		} catch (Exception e) {
			userAccount = null;
		}
		return userAccount;
	}
	
	
}
